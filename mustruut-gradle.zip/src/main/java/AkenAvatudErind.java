public class AkenAvatudErind extends Exception {
    public AkenAvatudErind(String message) {
        super(message);
    }
}
