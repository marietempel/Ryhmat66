import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Raamaturiiul {
    String asukohtVõiTunnusmärk;
    int ridu;
    int veerge;

    public Raamaturiiul(String asukohtVõiTunnusmärk, int ridu, int veerge) {
        this.asukohtVõiTunnusmärk = asukohtVõiTunnusmärk;
        this.ridu = ridu;
        this.veerge = veerge;
    }

    public String getAsukohtVõiTunnusmärk() {
        return asukohtVõiTunnusmärk;
    }

    public int getRidu() {
        return ridu;
    }

    public int getVeerge() {
        return veerge;
    }


    // meetod loob listi, kus on massiividena kõik read failist

    @Override
    public String toString() {
        return "Raamaturiiul{" +
                "asukohtVõiTunnusmärk='" + asukohtVõiTunnusmärk + '\'' +
                '}';
    }
}

